<?php

/*
 * Database configuration settings used by PDO.
 */


$config['dsn']      = 'mysql:host=localhost;dbname=gyac';
$config['password'] = '';
$config['user']     = 'root';
