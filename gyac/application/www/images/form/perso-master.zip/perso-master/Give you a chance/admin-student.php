<?php

session_start();

$template = "admin-student";
include 'layout.phtml';

?>